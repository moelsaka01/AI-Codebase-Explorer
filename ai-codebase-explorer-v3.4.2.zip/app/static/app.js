const uploadForm = document.getElementById("uploadForm");
const searchForm = document.getElementById("searchForm");
const askForm = document.getElementById("askForm");
const statusEl = document.getElementById("status");
const resultsSection = document.getElementById("resultsSection");
const fileInput = document.getElementById("repoZip");
const githubInput = document.getElementById("githubUrl");
const fileNameEl = document.getElementById("selectedFileName");
const fileHintEl = document.getElementById("selectedFileHint");
const graphSvg = document.getElementById("graphSvg");

let currentAnalysisId = null;
let exportCache = null;

function setStatus(message, variant = "neutral") {
  statusEl.textContent = message;
  statusEl.className = `status-chip ${variant}`;
}

function escapeHtml(value = "") {
  return String(value)
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#39;");
}

function shortLabel(text = "", max = 34) {
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
}

function fillList(elementId, items, formatter, emptyMessage = "Nothing to show.") {
  const el = document.getElementById(elementId);
  el.innerHTML = "";
  if (!items || items.length === 0) {
    el.innerHTML = `<li class="empty-item">${escapeHtml(emptyMessage)}</li>`;
    return;
  }
  items.forEach((item) => {
    const li = document.createElement("li");
    li.innerHTML = formatter ? formatter(item) : escapeHtml(String(item));
    el.appendChild(li);
  });
}

function renderBars(elementId, items) {
  const container = document.getElementById(elementId);
  container.innerHTML = "";
  if (!items || items.length === 0) {
    container.innerHTML = '<div class="empty-item">No data available.</div>';
    return;
  }
  const maxValue = Math.max(...items.map((item) => item.value), 1);
  items.forEach((item) => {
    const row = document.createElement("div");
    row.className = "bar-row";
    const width = Math.max(8, Math.round((item.value / maxValue) * 100));
    row.innerHTML = `
      <div class="bar-meta"><span>${escapeHtml(item.label)}</span><strong>${item.value}</strong></div>
      <div class="bar-track"><div class="bar-fill" style="width:${width}%"></div></div>
    `;
    container.appendChild(row);
  });
}

function renderRepoSignals(items) {
  const container = document.getElementById("repoSignals");
  container.innerHTML = "";
  if (!items || items.length === 0) {
    container.innerHTML = '<div class="empty-item">No signals available.</div>';
    return;
  }
  items.forEach((item) => {
    const div = document.createElement("div");
    div.className = "mini-metric";
    div.innerHTML = `<span>${escapeHtml(item.label)}</span><strong>${item.value}</strong>`;
    container.appendChild(div);
  });
}

function renderFlow(items) {
  const container = document.getElementById("pipelineFlow");
  container.innerHTML = "";
  if (!items || items.length === 0) {
    container.innerHTML = '<div class="empty-item">No clear pipeline inferred.</div>';
    return;
  }
  items.forEach((item) => {
    const div = document.createElement("div");
    div.className = "flow-node";
    div.textContent = item;
    container.appendChild(div);
  });
}

function renderInsightList(elementId, items, emptyMessage) {
  fillList(
    elementId,
    items,
    (item) => `
      <div class="insight-card ${escapeHtml(item.severity || "info")}">
        <h4>${escapeHtml(item.title)}</h4>
        <small>${escapeHtml(item.detail)}</small>
      </div>
    `,
    emptyMessage
  );
}

function renderSimilarRepos(items) {
  fillList(
    "similarRepos",
    items,
    (item) => `
      <div class="insight-card info">
        <h4>${escapeHtml(item.repo_name)} <span class="line-pill">${item.similarity_score}% match</span></h4>
        <small>${escapeHtml(item.reason)}</small>
      </div>
    `,
    "No similar analyzed repositories yet. Analyze more repos to unlock comparison."
  );
}

function renderStackGrid(items) {
  const container = document.getElementById("stackList");
  container.innerHTML = "";
  if (!items || items.length === 0) {
    container.innerHTML = '<div class="empty-item">No stack signals detected.</div>';
    return;
  }
  items.forEach((item) => {
    const card = document.createElement("div");
    card.className = "stack-card";
    const match = String(item).match(/^(.*?)(\s*\((\d+) files\))?$/);
    const label = match ? match[1].trim() : String(item);
    const meta = match && match[3] ? `${match[3]} file(s)` : "Framework or architectural signal";
    card.innerHTML = `<div class="stack-type">${escapeHtml(label)}</div><div class="stack-meta">${escapeHtml(meta)}</div>`;
    container.appendChild(card);
  });
}

function drawArrowMarker() {
  const defs = document.createElementNS("http://www.w3.org/2000/svg", "defs");
  const marker = document.createElementNS("http://www.w3.org/2000/svg", "marker");
  marker.setAttribute("id", "arrowhead");
  marker.setAttribute("viewBox", "0 0 10 10");
  marker.setAttribute("refX", "8");
  marker.setAttribute("refY", "5");
  marker.setAttribute("markerWidth", "7");
  marker.setAttribute("markerHeight", "7");
  marker.setAttribute("orient", "auto-start-reverse");
  const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
  path.setAttribute("d", "M 0 0 L 10 5 L 0 10 z");
  path.setAttribute("fill", "rgba(117,166,255,0.65)");
  marker.appendChild(path);
  defs.appendChild(marker);
  graphSvg.appendChild(defs);
}

function nodePriority(kind = "") {
  if (kind === "entry") return 0;
  if (kind === "config" || kind === "deps") return 1;
  if (["detect", "track", "analytics", "inference", "api", "service", "database", "ui"].includes(kind)) return 2;
  return 3;
}

function layoutGraphNodes(nodes) {
  const width = Math.max(980, graphSvg.parentElement?.clientWidth || 980);
  const sorted = [...nodes].sort((a, b) => {
    const pa = nodePriority(a.kind || "");
    const pb = nodePriority(b.kind || "");
    if (pa !== pb) return pa - pb;
    return String(a.label || "").localeCompare(String(b.label || ""));
  });

  const count = sorted.length;
  const cols = count >= 16 ? 4 : count >= 8 ? 3 : 2;
  const outerPad = 36;
  const colGap = 28;
  const rowGap = 26;
  const nodeWidth = Math.max(180, Math.min(220, Math.floor((width - outerPad * 2 - colGap * (cols - 1)) / cols)));
  const nodeHeight = 96;
  const rows = Math.ceil(count / cols);
  const height = Math.max(420, outerPad * 2 + rows * nodeHeight + (rows - 1) * rowGap);

  const laidOut = sorted.map((node, idx) => {
    const col = idx % cols;
    const row = Math.floor(idx / cols);
    const x = outerPad + col * (nodeWidth + colGap);
    const y = outerPad + row * (nodeHeight + rowGap);
    return { ...node, width: nodeWidth, height: nodeHeight, x, y };
  });

  return { nodes: laidOut, width, height };
}

function renderGraph(nodes, edges) {
  graphSvg.innerHTML = "";
  if (!nodes || nodes.length === 0) {
    graphSvg.innerHTML = '<text x="40" y="60" fill="#9eacc9">No graph data available.</text>';
    return;
  }

  const { nodes: laidOut, width, height } = layoutGraphNodes(nodes);
  graphSvg.setAttribute("viewBox", `0 0 ${width} ${height}`);
  graphSvg.style.height = `${Math.max(520, height)}px`;

  drawArrowMarker();
  const nodeMap = Object.fromEntries(laidOut.map((node) => [node.id, node]));

  edges.forEach((edge) => {
    const source = nodeMap[edge.source];
    const target = nodeMap[edge.target];
    if (!source || !target) return;

    const sx = source.x + source.width / 2;
    const sy = source.y + source.height;
    const tx = target.x + target.width / 2;
    const ty = target.y;
    const midY = sy + Math.max(28, (ty - sy) / 2);
    const pathData = `M ${sx} ${sy} C ${sx} ${midY}, ${tx} ${midY}, ${tx} ${ty}`;

    const path = document.createElementNS("http://www.w3.org/2000/svg", "path");
    path.setAttribute("d", pathData);
    path.setAttribute("class", edge.kind === "import" ? "edge-import" : "edge-flow");
    path.setAttribute("marker-end", "url(#arrowhead)");
    graphSvg.appendChild(path);
  });

  laidOut.forEach((node) => {
    const group = document.createElementNS("http://www.w3.org/2000/svg", "g");
    const width = node.width || 170;
    const height = node.height || 72;
    const x = node.x;
    const y = node.y;
    const nodeClass = node.kind === "entry"
      ? "node-entry"
      : node.kind === "config" || node.kind === "deps"
      ? "node-config"
      : ["detect", "track", "analytics", "inference", "api", "service", "database", "ui"].includes(node.kind)
      ? "node-pipeline"
      : "node-file";

    const rect = document.createElementNS("http://www.w3.org/2000/svg", "rect");
    rect.setAttribute("x", x);
    rect.setAttribute("y", y);
    rect.setAttribute("rx", "22");
    rect.setAttribute("ry", "22");
    rect.setAttribute("width", width);
    rect.setAttribute("height", height);
    rect.setAttribute("class", `node-card ${nodeClass}`);
    group.appendChild(rect);

    const label = document.createElementNS("http://www.w3.org/2000/svg", "text");
    label.setAttribute("x", x + width / 2);
    label.setAttribute("y", y + 34);
    label.setAttribute("text-anchor", "middle");
    label.setAttribute("class", "node-label");
    const labelLines = String(shortLabel(node.label, 42)).match(/.{1,20}/g) || [node.label || ""];
    labelLines.slice(0, 2).forEach((lineText, index) => {
      const tspan = document.createElementNS("http://www.w3.org/2000/svg", "tspan");
      tspan.setAttribute("x", x + width / 2);
      tspan.setAttribute("dy", index === 0 ? "0" : "18");
      tspan.textContent = lineText;
      label.appendChild(tspan);
    });
    group.appendChild(label);

    const subtitle = document.createElementNS("http://www.w3.org/2000/svg", "text");
    subtitle.setAttribute("x", x + width / 2);
    subtitle.setAttribute("y", y + height - 16);
    subtitle.setAttribute("text-anchor", "middle");
    subtitle.setAttribute("class", "node-subtitle");
    subtitle.textContent = shortLabel(node.subtitle || "", 32);
    group.appendChild(subtitle);

    graphSvg.appendChild(group);
  });
}

function normalizeGithubUrl(raw = "") {
  const value = String(raw).trim();
  if (!value) return "";
  let normalized = value;
  if (!/^https?:\/\//i.test(normalized)) {
    normalized = `https://${normalized}`;
  }
  try {
    const url = new URL(normalized);
    const host = url.hostname.replace(/^www\./i, "").toLowerCase();
    if (host !== "github.com") return value;
    const parts = url.pathname.split("/").filter(Boolean);
    if (parts.length < 2) return `https://github.com/${parts.join("/")}`;
    return `https://github.com/${parts[0]}/${parts[1].replace(/\.git$/i, "")}`;
  } catch {
    return value;
  }
}

function updateFileSelectionState() {
  const file = fileInput.files[0];
  const githubUrl = normalizeGithubUrl(githubInput.value.trim());
  if (file) {
    fileNameEl.textContent = file.name;
    fileHintEl.textContent = `Selected file, ${(file.size / (1024 * 1024)).toFixed(2)} MB. Ready to analyze.`;
    setStatus("Zip file selected. Click Analyze Codebase.", "ready");
    return;
  }
  if (githubUrl) {
    fileNameEl.textContent = "GitHub URL mode";
    fileHintEl.textContent = githubUrl;
    setStatus("GitHub URL detected. Click Analyze Codebase.", "ready");
    return;
  }
  fileNameEl.textContent = "Choose a .zip file";
  fileHintEl.textContent = "The app will inspect source files and expand nested zip archives when possible.";
  setStatus("Waiting for upload or GitHub URL", "neutral");
}

function renderSearchResults(elementId, results, emptyText) {
  const resultsEl = document.getElementById(elementId);
  resultsEl.innerHTML = "";
  if (!results || results.length === 0) {
    resultsEl.innerHTML = `<li class="empty-item">${escapeHtml(emptyText)}</li>`;
    return;
  }
  results.forEach((result) => {
    const li = document.createElement("li");
    li.className = "search-item";
    li.innerHTML = `
      <div class="search-top">
        <strong>${escapeHtml(result.path)}</strong>
        <span class="line-pill">${result.matched_line ? `Line ${result.matched_line}` : "Source"}</span>
      </div>
      <div class="search-snippet">${escapeHtml(result.snippet || "")}</div>
      <div class="search-reason">${escapeHtml(result.reason || "")}</div>
    `;
    resultsEl.appendChild(li);
  });
}

async function fetchExport() {
  if (!currentAnalysisId) return null;
  if (exportCache) return exportCache;
  const response = await fetch(`/api/export/${currentAnalysisId}`);
  const data = await response.json();
  if (!response.ok) throw new Error(data.detail || "Export failed.");
  exportCache = data;
  return data;
}

function downloadText(filename, content) {
  const blob = new Blob([content], { type: "text/plain;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

fileInput.addEventListener("change", () => {
  if (fileInput.files[0]) {
    githubInput.value = "";
  }
  updateFileSelectionState();
});
githubInput.addEventListener("input", () => {
  if (githubInput.value.trim()) {
    fileInput.value = "";
  }
  updateFileSelectionState();
});

document.getElementById("downloadMermaidBtn").addEventListener("click", async () => {
  try {
    const exp = await fetchExport();
    if (exp) downloadText(`${currentAnalysisId}-architecture.mmd`, exp.mermaid);
  } catch (error) {
    setStatus(error.message, "error");
  }
});

document.getElementById("downloadPlantBtn").addEventListener("click", async () => {
  try {
    const exp = await fetchExport();
    if (exp) downloadText(`${currentAnalysisId}-architecture.puml`, exp.plantuml);
  } catch (error) {
    setStatus(error.message, "error");
  }
});

uploadForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  const file = fileInput.files[0];
  const githubUrl = normalizeGithubUrl(githubInput.value.trim());
  if (githubUrl) githubInput.value = githubUrl;
  if (!file && !githubUrl) {
    setStatus("Please choose a zip file or paste a public GitHub URL first.", "error");
    return;
  }

  setStatus("Analyzing repository, this can take a little longer for larger projects.", "loading");
  try {
    let response;
    if (githubUrl && !file) {
      response = await fetch("/api/analyze", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ github_url: githubUrl }),
      });
    } else {
      const formData = new FormData();
      if (file) formData.append("file", file);
      if (githubUrl) formData.append("github_url", githubUrl);
      response = await fetch("/api/analyze", { method: "POST", body: formData });
    }
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Analysis failed.");

    currentAnalysisId = data.analysis_id;
    exportCache = null;
    document.getElementById("repoName").textContent = data.repo_name;
    document.getElementById("analysisId").textContent = data.analysis_id;
    document.getElementById("repoSource").textContent = data.repo_source;
    document.getElementById("overview").textContent = data.overview;
    document.getElementById("projectSummary").textContent = data.project_summary;
    document.getElementById("totalSupportedFiles").textContent = data.total_supported_files;
    document.getElementById("totalScannedFiles").textContent = data.total_scanned_files;
    document.getElementById("nestedArchivesProcessed").textContent = data.nested_archives_processed;
    document.getElementById("entryPointCount").textContent = data.entry_points.length;
    document.getElementById("healthScore").textContent = data.health_score;
    document.getElementById("healthRing").style.setProperty("--score", data.health_score);
    document.getElementById("architectureMermaid").textContent = data.architecture_mermaid;
    document.getElementById("fileTree").textContent = data.file_tree.join("\n");
    document.getElementById("dependencyEdges").textContent = data.dependency_edges.length
      ? data.dependency_edges.map((edge) => `${edge.source} -> ${edge.target}`).join("\n")
      : "No import or require relationships were detected in supported files.";
    document.getElementById("generatedReadme").textContent = data.generated_readme;

    renderStackGrid(data.detected_stack);
    fillList("archiveList", data.discovered_archives, (item) => `<code>${escapeHtml(item)}</code>`, "No nested archives were expanded.");
    fillList("entryPoints", data.entry_points, (item) => `<code>${escapeHtml(item)}</code>`, "No obvious entry point detected.");
    fillList("notes", data.architecture_notes, (item) => escapeHtml(item), "No architecture notes generated.");
    fillList("onboardingGuide", data.onboarding_guide, (item) => escapeHtml(item), "No onboarding guide available.");
    fillList(
      "keyModules",
      data.key_modules,
      (item) => `
        <div class="module-card">
          <div class="module-title">${escapeHtml(item.path)}</div>
          <div class="module-meta">${escapeHtml(item.role)} · ${escapeHtml(item.language)} · ${item.lines} lines</div>
        </div>
      `,
      "No key modules selected."
    );

    renderBars("languageBars", data.language_breakdown);
    renderBars("roleBars", data.role_breakdown);
    renderBars("healthBreakdown", data.health_breakdown);
    renderRepoSignals(data.repo_signals);
    renderFlow(data.pipeline_flow);
    renderGraph(data.architecture_svg_nodes, data.architecture_svg_edges);
    renderInsightList("antiPatterns", data.anti_patterns, "No anti-pattern signals found.");
    renderInsightList("refactorSuggestions", data.refactor_suggestions, "No refactor suggestions generated.");
    renderInsightList("securityFindings", data.security_findings, "No dependency risk notes available.");
    renderSimilarRepos(data.similar_repositories);

    resultsSection.classList.remove("hidden");
    renderSearchResults("askSources", [], "Ask a question to see relevant files.");
    renderSearchResults("searchResults", [], "Search results will appear here.");
    document.getElementById("searchExplanation").textContent = "";
    document.getElementById("askAnswer").textContent = "Ask a question such as 'How does this codebase start running?' or 'What should I refactor first?'";
    document.getElementById("askMode").textContent = "Mode: heuristic AI assistant";
    fileHintEl.textContent = `Analyzed ${data.repo_name}. Scroll down to explore the graph, health score, and onboarding guide.`;
    setStatus("Analysis complete. Explore the graph, health score, and codebase assistant below.", "success");
    resultsSection.scrollIntoView({ behavior: "smooth", block: "start" });
  } catch (error) {
    setStatus(error.message, "error");
  }
});

searchForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!currentAnalysisId) {
    setStatus("Analyze a repository first.", "error");
    return;
  }
  const query = document.getElementById("query").value.trim();
  const explanationEl = document.getElementById("searchExplanation");
  explanationEl.textContent = "Searching...";
  try {
    const response = await fetch("/api/search", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ analysis_id: currentAnalysisId, query }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Search failed.");
    explanationEl.textContent = data.explanation;
    renderSearchResults("searchResults", data.results, "No direct matches found.");
  } catch (error) {
    explanationEl.textContent = error.message;
  }
});

askForm.addEventListener("submit", async (event) => {
  event.preventDefault();
  if (!currentAnalysisId) {
    setStatus("Analyze a repository first.", "error");
    return;
  }
  const question = document.getElementById("question").value.trim();
  document.getElementById("askAnswer").textContent = "Thinking about the repository...";
  try {
    const response = await fetch("/api/ask", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ analysis_id: currentAnalysisId, question }),
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.detail || "Ask failed.");
    document.getElementById("askMode").textContent = `Mode: ${data.mode}`;
    document.getElementById("askAnswer").textContent = data.answer;
    renderSearchResults("askSources", data.sources, "No supporting files found for that question.");
  } catch (error) {
    document.getElementById("askAnswer").textContent = error.message;
  }
});

updateFileSelectionState();
