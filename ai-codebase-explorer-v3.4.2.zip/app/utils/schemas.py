from typing import List, Optional

from pydantic import BaseModel


class FileSummary(BaseModel):
    path: str
    language: str
    role: str
    lines: int = 0


class ModuleEdge(BaseModel):
    source: str
    target: str


class SearchResult(BaseModel):
    path: str
    matched_line: Optional[int] = None
    snippet: str
    reason: str


class MetricItem(BaseModel):
    label: str
    value: int


class InsightItem(BaseModel):
    title: str
    detail: str
    severity: str = "info"


class SimilarRepo(BaseModel):
    repo_name: str
    similarity_score: int
    reason: str
    analysis_id: Optional[str] = None


class AskAnswer(BaseModel):
    question: str
    answer: str
    sources: List[SearchResult]
    mode: str


class AnalysisResponse(BaseModel):
    analysis_id: str
    repo_name: str
    repo_source: str
    overview: str
    project_summary: str
    detected_stack: List[str]
    key_modules: List[FileSummary]
    entry_points: List[str]
    architecture_notes: List[str]
    onboarding_guide: List[str]
    pipeline_flow: List[str]
    file_tree: List[str]
    dependency_edges: List[ModuleEdge]
    architecture_mermaid: str
    architecture_svg_nodes: List[dict]
    architecture_svg_edges: List[dict]
    generated_readme: str
    total_supported_files: int
    total_scanned_files: int
    nested_archives_processed: int
    discovered_archives: List[str]
    language_breakdown: List[MetricItem]
    role_breakdown: List[MetricItem]
    health_score: int
    health_breakdown: List[MetricItem]
    anti_patterns: List[InsightItem]
    refactor_suggestions: List[InsightItem]
    security_findings: List[InsightItem]
    similar_repositories: List[SimilarRepo]
    repo_signals: List[MetricItem]


class SearchRequest(BaseModel):
    analysis_id: str
    query: str


class SearchResponse(BaseModel):
    analysis_id: str
    query: str
    explanation: str
    results: List[SearchResult]


class AskRequest(BaseModel):
    analysis_id: str
    question: str


class ExportResponse(BaseModel):
    analysis_id: str
    mermaid: str
    plantuml: str
