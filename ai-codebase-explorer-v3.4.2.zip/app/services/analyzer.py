from __future__ import annotations

import json
import math
import os
import re
import shutil
import tempfile
import uuid
import zipfile
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import urlparse

import requests


class AnalyzerService:
    ANALYSIS_STORE: Dict[str, Dict[str, Any]] = {}
    ANALYSIS_HISTORY: List[Dict[str, Any]] = []

    SUPPORTED_EXTENSIONS = {
        ".py": "Python",
        ".js": "JavaScript",
        ".ts": "TypeScript",
        ".jsx": "JavaScript",
        ".tsx": "TypeScript",
        ".java": "Java",
        ".go": "Go",
        ".rs": "Rust",
        ".cpp": "C++",
        ".c": "C",
        ".cs": "C#",
        ".php": "PHP",
        ".rb": "Ruby",
        ".swift": "Swift",
        ".kt": "Kotlin",
        ".scala": "Scala",
        ".r": "R",
        ".lua": "Lua",
        ".sh": "Shell",
        ".html": "HTML",
        ".css": "CSS",
        ".scss": "SCSS",
        ".md": "Markdown",
        ".yaml": "YAML",
        ".yml": "YAML",
        ".json": "JSON",
        ".toml": "TOML",
        ".ini": "INI",
        ".cfg": "Config",
        ".txt": "Text",
    }

    TEXT_LIKE_EXTENSIONS = set(SUPPORTED_EXTENSIONS.keys())
    MAX_TEXT_BYTES = 300_000
    MAX_SEARCH_RESULTS = 25
    MAX_NESTED_ARCHIVE_DEPTH = 2

    IMPORT_PATTERNS = [
        re.compile(r"^\s*import\s+([a-zA-Z0-9_., ]+)", re.MULTILINE),
        re.compile(r"^\s*from\s+([a-zA-Z0-9_.]+)\s+import\s+", re.MULTILINE),
        re.compile(r'require\(["\']([^"\']+)["\']\)'),
        re.compile(r'import\s+.*?from\s+["\']([^"\']+)["\']'),
    ]

    EXECUTION_PATTERNS = [
        re.compile(r'if\s+__name__\s*==\s*["\']__main__["\']'),
        re.compile(r'uvicorn\.run\('),
        re.compile(r'app\.run\('),
        re.compile(r'FastAPI\('),
        re.compile(r'argparse\.ArgumentParser'),
        re.compile(r'click\.command'),
    ]

    PIPELINE_HINTS = {
        "detect": ["detect", "detector", "yolo", "inference"],
        "track": ["track", "tracker", "deepsort", "sort"],
        "analytics": ["metric", "analytics", "trajectory", "report"],
        "api": ["api", "route", "router", "endpoint"],
        "service": ["service", "manager", "engine"],
        "database": ["database", "db", "sql", "model"],
        "ui": ["component", "view", "template", "frontend", "ui"],
    }

    RISKY_DEPENDENCY_HINTS = {
        "opencv-python": "Computer vision dependency, verify CVE status in real security tooling.",
        "pillow": "Image library, verify version against current advisories.",
        "pyyaml": "YAML parser, ensure safe loading is used.",
        "requests": "Networking library, keep patched and verify TLS handling.",
        "flask": "Web framework, verify pinned version.",
        "django": "Web framework, verify pinned version.",
        "fastapi": "API framework, keep dependencies patched.",
        "numpy": "Core numeric dependency, keep version pinned.",
        "torch": "Large ML dependency, validate runtime compatibility and version pinning.",
    }

    @staticmethod
    def _safe_read_text(path: Path) -> str:
        try:
            if path.stat().st_size > AnalyzerService.MAX_TEXT_BYTES:
                with open(path, "rb") as f:
                    return f.read(AnalyzerService.MAX_TEXT_BYTES).decode("utf-8", errors="ignore")
            return path.read_text(encoding="utf-8", errors="ignore")
        except Exception:
            return ""

    @staticmethod
    def _line_count(path: Path) -> int:
        try:
            with open(path, "rb") as f:
                return sum(1 for _ in f)
        except Exception:
            return 0

    @staticmethod
    def _rel(path: Path, root: Path) -> str:
        try:
            return path.relative_to(root).as_posix()
        except Exception:
            return path.name

    @staticmethod
    def _normalize_nested_display(rel_path: str) -> str:
        m = re.match(r"_expanded_archives/([^/]+)_d\d+/(.+)", rel_path)
        if not m:
            return rel_path
        archive_stem = m.group(1)
        inner_path = m.group(2)
        return f"{archive_stem}.zip::{inner_path}"

    @staticmethod
    def _language_for_path(path: Path) -> str:
        return AnalyzerService.SUPPORTED_EXTENSIONS.get(path.suffix.lower(), "Other")

    @staticmethod
    def _is_supported_source(path: Path) -> bool:
        return path.suffix.lower() in AnalyzerService.SUPPORTED_EXTENSIONS or path.name in {
            "requirements.txt", "Dockerfile", "docker-compose.yml", "docker-compose.yaml", "pyproject.toml", "package.json", "setup.py"
        }

    @staticmethod
    def _is_text_like(path: Path) -> bool:
        return path.suffix.lower() in AnalyzerService.TEXT_LIKE_EXTENSIONS or path.name in {
            "requirements.txt", "Dockerfile", "docker-compose.yml", "docker-compose.yaml", "pyproject.toml", "package.json", "setup.py"
        }

    @staticmethod
    def _extract_zip(zip_path: Path, extract_to: Path) -> Path:
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_to)
        dirs = [p for p in extract_to.iterdir() if p.is_dir()]
        if len(dirs) == 1:
            return dirs[0]
        return extract_to

    @staticmethod
    def fetch_github_repo(github_url: str, dest_zip_path: Path) -> str:
        raw_url = github_url.strip()
        if raw_url.startswith("github.com/"):
            raw_url = f"https://{raw_url}"
        parsed = urlparse(raw_url)
        host = parsed.netloc.lower().replace("www.", "")
        if host != "github.com":
            raise ValueError("Please provide a public GitHub repository URL.")
        parts = [part for part in parsed.path.split("/") if part]
        if len(parts) < 2:
            raise ValueError("GitHub URL format should look like https://github.com/owner/repo")
        owner = parts[0]
        repo = parts[1].removesuffix(".git")
        requested_branch = None
        if len(parts) >= 4 and parts[2] in {"tree", "blob"}:
            requested_branch = parts[3]

        dest_zip_path.parent.mkdir(parents=True, exist_ok=True)

        session = requests.Session()
        session.headers.update({
            "User-Agent": "AI-Codebase-Explorer/3.6",
            "Accept": "application/vnd.github+json",
        })

        branches: List[str] = []
        try:
            meta_url = f"https://api.github.com/repos/{owner}/{repo}"
            meta_resp = session.get(meta_url, timeout=30)
            if meta_resp.ok:
                default_branch = meta_resp.json().get("default_branch")
                if requested_branch:
                    branches.append(requested_branch)
                if default_branch and default_branch not in branches:
                    branches.append(default_branch)
        except Exception:
            # GitHub API can fail due to rate limit or network quirks, so keep going with fallbacks.
            pass

        for fallback in ["main", "master"]:
            if fallback not in branches:
                branches.append(fallback)

        last_error: Exception | None = None
        for branch in branches:
            for zip_url in [
                f"https://codeload.github.com/{owner}/{repo}/zip/refs/heads/{branch}",
                f"https://github.com/{owner}/{repo}/archive/refs/heads/{branch}.zip",
            ]:
                try:
                    with session.get(zip_url, timeout=120, stream=True, allow_redirects=True) as response:
                        if response.status_code != 200:
                            last_error = RuntimeError(f"HTTP {response.status_code} for {zip_url}")
                            continue
                        with dest_zip_path.open("wb") as out:
                            for chunk in response.iter_content(chunk_size=1024 * 1024):
                                if chunk:
                                    out.write(chunk)
                    if not zipfile.is_zipfile(dest_zip_path):
                        preview = dest_zip_path.read_bytes()[:200].decode("utf-8", errors="ignore")
                        last_error = RuntimeError(f"Downloaded file was not a zip for {zip_url}. Preview: {preview}")
                        continue
                    return f"GitHub URL: https://github.com/{owner}/{repo}"
                except Exception as exc:
                    last_error = exc
                    continue

        raise ValueError(f"Could not download that GitHub repository. Last error: {last_error}")

    @staticmethod
    def _expand_nested_archives(root: Path, depth: int = 0) -> List[str]:
        if depth >= AnalyzerService.MAX_NESTED_ARCHIVE_DEPTH:
            return []
        found: List[str] = []
        archive_root = root / "_expanded_archives"
        archive_root.mkdir(parents=True, exist_ok=True)

        zip_files = [p for p in root.rglob("*.zip") if p.is_file() and "_expanded_archives" not in p.as_posix()]
        for z in zip_files:
            try:
                target_dir = archive_root / f"{z.stem}_d{depth + 1}"
                target_dir.mkdir(parents=True, exist_ok=True)
                with zipfile.ZipFile(z, "r") as zf:
                    zf.extractall(target_dir)
                found.append(z.name)
                found.extend(AnalyzerService._expand_nested_archives(target_dir, depth + 1))
            except Exception:
                continue
        return sorted(list(dict.fromkeys(found)))

    @staticmethod
    def _detect_role(path: Path, text: str) -> str:
        name = path.name.lower()
        rel = path.as_posix().lower()
        if name in {"requirements.txt", "pyproject.toml", "package.json", "setup.py"}:
            return "Dependency manifest"
        if name in {"dockerfile", "docker-compose.yml", "docker-compose.yaml"}:
            return "Deployment"
        if name in {"config.yaml", "config.yml", ".env", ".env.example", "settings.py"}:
            return "Configuration"
        if "test" in name or any(h in rel for h in ["/tests/", "\\tests\\"]):
            return "Tests"
        if name in {"readme.md", "changelog.md", "contributing.md"}:
            return "Documentation"
        if any(p.search(text) for p in AnalyzerService.EXECUTION_PATTERNS):
            return "Application entry point"
        if "/routes/" in rel or "/api/" in rel:
            return "API layer"
        if "/models/" in rel:
            return "Models"
        if "/utils/" in rel:
            return "Utilities"
        return "General module"

    @staticmethod
    def _detect_stack(files: List[Path], root: Path) -> List[str]:
        language_counts: Dict[str, int] = {}
        has_yolo = has_deepsort = has_fastapi = has_flask = has_django = has_react = has_node = False
        for f in files:
            lang = AnalyzerService._language_for_path(f)
            language_counts[lang] = language_counts.get(lang, 0) + 1
            text = AnalyzerService._safe_read_text(f).lower()
            rel = AnalyzerService._rel(f, root).lower()
            if "yolo" in text or "yolo" in rel:
                has_yolo = True
            if "deepsort" in text or "deepsort" in rel:
                has_deepsort = True
            if "fastapi" in text:
                has_fastapi = True
            if "flask" in text:
                has_flask = True
            if "django" in text:
                has_django = True
            if "react" in text:
                has_react = True
            if f.name == "package.json":
                has_node = True
        stack: List[str] = []
        if has_deepsort:
            stack.append("DeepSORT-style tracking")
        if has_yolo:
            stack.append("YOLO-based vision")
        if has_fastapi:
            stack.append("FastAPI")
        if has_flask:
            stack.append("Flask")
        if has_django:
            stack.append("Django")
        if has_react:
            stack.append("React")
        if has_node:
            stack.append("Node.js")
        for lang, count in sorted(language_counts.items(), key=lambda x: (-x[1], x[0])):
            stack.append(f"{lang} ({count} files)")
        return stack

    @staticmethod
    def _extract_imports(text: str) -> List[str]:
        found: List[str] = []
        for pattern in AnalyzerService.IMPORT_PATTERNS:
            for match in pattern.findall(text):
                if isinstance(match, tuple):
                    match = match[0]
                if not match:
                    continue
                if "," in match:
                    found.extend([p.strip() for p in match.split(",") if p.strip()])
                else:
                    found.append(match.strip())
        cleaned = []
        for item in found:
            item = item.replace(" as ", " ").split()[0].strip()
            if item:
                cleaned.append(item)
        return sorted(list(dict.fromkeys(cleaned)))

    @staticmethod
    def _module_name_candidates(path: Path, root: Path) -> List[str]:
        rel = AnalyzerService._rel(path, root)
        no_suffix = rel.rsplit(".", 1)[0]
        dotted = no_suffix.replace("/", ".")
        parts = dotted.split(".")
        candidates = [dotted]
        if parts:
            candidates.append(parts[-1])
        return list(dict.fromkeys([c for c in candidates if c]))

    @staticmethod
    def _build_dependency_edges(files: List[Path], root: Path) -> List[Dict[str, str]]:
        module_lookup: Dict[str, str] = {}
        for f in files:
            for candidate in AnalyzerService._module_name_candidates(f, root):
                module_lookup[candidate] = AnalyzerService._normalize_nested_display(AnalyzerService._rel(f, root))
        edges: List[Dict[str, str]] = []
        seen = set()
        for f in files:
            text = AnalyzerService._safe_read_text(f)
            imports = AnalyzerService._extract_imports(text)
            src = AnalyzerService._normalize_nested_display(AnalyzerService._rel(f, root))
            for imp in imports:
                target = module_lookup.get(imp) or module_lookup.get(imp.split(".")[0])
                if target and target != src:
                    key = (src, target)
                    if key not in seen:
                        edges.append({"from": src, "to": target})
                        seen.add(key)
        return edges

    @staticmethod
    def _find_entry_points(files: List[Path], root: Path) -> List[str]:
        entry_points: List[str] = []
        for f in files:
            text = AnalyzerService._safe_read_text(f)
            if AnalyzerService._detect_role(f, text) == "Application entry point":
                entry_points.append(AnalyzerService._normalize_nested_display(AnalyzerService._rel(f, root)))
        if not entry_points:
            for f in files:
                if f.name.lower() in {"main.py", "app.py", "server.py", "manage.py", "index.js"}:
                    entry_points.append(AnalyzerService._normalize_nested_display(AnalyzerService._rel(f, root)))
        return sorted(list(dict.fromkeys(entry_points)))

    @staticmethod
    def _language_breakdown(files: List[Path]) -> List[Dict[str, Any]]:
        counts: Dict[str, int] = {}
        for f in files:
            lang = AnalyzerService._language_for_path(f)
            counts[lang] = counts.get(lang, 0) + 1
        return [{"label": k, "value": v} for k, v in sorted(counts.items(), key=lambda x: (-x[1], x[0]))]

    @staticmethod
    def _role_breakdown(file_infos: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        counts: Dict[str, int] = {}
        for info in file_infos:
            counts[info["role"]] = counts.get(info["role"], 0) + 1
        return [{"label": k, "value": v} for k, v in sorted(counts.items(), key=lambda x: (-x[1], x[0]))]

    @staticmethod
    def _score_role_kind(path: str, role: str) -> str:
        low = f"{path} {role}".lower()
        if role == "Application entry point":
            return "entry"
        if role in {"Configuration", "Dependency manifest", "Deployment"}:
            return "config"
        for kind, hints in AnalyzerService.PIPELINE_HINTS.items():
            if any(h in low for h in hints):
                return kind
        return "file"

    @staticmethod
    def _graph_nodes(file_infos: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        selected = file_infos[:18]
        cols = 3
        x_positions = [150, 410, 670]
        y_start = 24
        y_step = 100
        nodes: List[Dict[str, Any]] = []
        for idx, info in enumerate(selected):
            col = idx % cols
            row = idx // cols
            kind = AnalyzerService._score_role_kind(info["path"], info["role"])
            nodes.append({
                "id": info["path"],
                "label": Path(info["path"]).name,
                "subtitle": info["role"],
                "kind": kind,
                "x": x_positions[col],
                "y": y_start + row * y_step,
                "width": 190,
                "height": 78,
            })
        return nodes

    @staticmethod
    def _graph_edges(dependency_edges: List[Dict[str, str]], file_infos: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        node_ids = {i["path"] for i in file_infos[:18]}
        edges: List[Dict[str, Any]] = []
        for edge in dependency_edges[:40]:
            if edge["from"] in node_ids and edge["to"] in node_ids:
                edges.append({"source": edge["from"], "target": edge["to"], "kind": "import"})
        if edges:
            return edges
        entry = [f["path"] for f in file_infos if f["role"] == "Application entry point"]
        config = [f["path"] for f in file_infos if f["role"] == "Configuration"]
        deps = [f["path"] for f in file_infos if f["role"] == "Dependency manifest"]
        flow: List[Dict[str, Any]] = []
        if entry and config:
            flow.append({"source": entry[0], "target": config[0], "kind": "flow"})
        if entry and deps:
            flow.append({"source": entry[0], "target": deps[0], "kind": "flow"})
        return flow

    @staticmethod
    def _health_score(file_infos: List[Dict[str, Any]], entry_points: List[str], dependency_edges: List[Dict[str, str]]) -> Dict[str, Any]:
        docs_score = 22 if any(i["role"] == "Documentation" for i in file_infos) else 8
        arch_score = 18 if entry_points else 8
        dep_score = 14 if dependency_edges else 6
        config_score = 14 if any(i["role"] == "Configuration" for i in file_infos) else 6
        test_score = 12 if any(i["role"] == "Tests" for i in file_infos) else 6
        code_files = [i for i in file_infos if i["language"] not in {"Markdown", "YAML", "JSON", "TOML", "INI", "Config", "Text"}]
        avg_size = sum(i["line_count"] for i in code_files) / max(1, len(code_files)) if code_files else 0
        module_size_score = 14 if avg_size < 400 else 8
        total = max(0, min(100, docs_score + arch_score + dep_score + config_score + test_score + module_size_score))
        return {"score": total, "parts": [
            {"label": "Documentation", "value": docs_score},
            {"label": "Architecture clarity", "value": arch_score},
            {"label": "Dependency visibility", "value": dep_score},
            {"label": "Config hygiene", "value": config_score},
            {"label": "Testing signal", "value": test_score},
            {"label": "Module size", "value": module_size_score},
        ]}

    @staticmethod
    def _anti_patterns(file_infos: List[Dict[str, Any]], nested_archives: List[str], dependency_edges: List[Dict[str, str]]) -> List[Dict[str, str]]:
        items = []
        if not any(i["role"] == "Tests" for i in file_infos):
            items.append({"title": "No obvious tests found", "detail": "The analyzer did not find test-oriented files. That lowers confidence in safe refactoring and onboarding.", "severity": "warning"})
        if nested_archives:
            items.append({"title": "Nested archives hide source", "detail": "Inner zip files make architecture discovery harder for humans and tooling. Consider storing source folders directly in the repo.", "severity": "warning"})
        large_modules = [i for i in file_infos if i["line_count"] > 800]
        if large_modules:
            items.append({"title": "Large modules detected", "detail": f"{large_modules[0]['path']} is large enough to benefit from splitting by responsibility.", "severity": "info"})
        if not dependency_edges:
            items.append({"title": "Weak dependency visibility", "detail": "No internal import relationships were detected. This may mean the project is small, scaffold-like, or the current parser needs richer import support.", "severity": "info"})
        return items

    @staticmethod
    def _refactor_suggestions(file_infos: List[Dict[str, Any]], nested_archives: List[str]) -> List[Dict[str, str]]:
        items = []
        config_files = [i for i in file_infos if i["role"] == "Configuration"]
        if config_files:
            items.append({"title": "Promote config defaults", "detail": f"Document runtime options in {config_files[0]['path']} and mirror them in a .env.example or sample config.", "severity": "info"})
        if not any(i["role"] == "Tests" for i in file_infos):
            items.append({"title": "Add smoke tests", "detail": "Create one or two smoke tests for the main execution path so future architecture changes are safer.", "severity": "warning"})
        if nested_archives:
            items.append({"title": "Unpack source folders in Git", "detail": "Replace nested zip source bundles with normal folders to improve tooling, diffs, and contributor experience.", "severity": "info"})
        return items

    @staticmethod
    def _dependency_risks(files: List[Path]) -> List[Dict[str, str]]:
        risks: List[Dict[str, str]] = []
        manifests = [f for f in files if f.name in {"requirements.txt", "pyproject.toml", "package.json", "setup.py"}]
        for manifest in manifests:
            text = AnalyzerService._safe_read_text(manifest).lower()
            for pkg, detail in AnalyzerService.RISKY_DEPENDENCY_HINTS.items():
                if pkg in text:
                    risks.append({"title": pkg, "detail": detail, "severity": "info"})
        if not risks:
            risks.append({"title": "No obvious offline dependency risks", "detail": "This scanner uses offline heuristics. Pair it with a real CVE-backed audit before production release.", "severity": "info"})
        unique, seen = [], set()
        for item in risks:
            key = (item["title"], item["detail"])
            if key not in seen:
                unique.append(item)
                seen.add(key)
        return unique

    @staticmethod
    def _pipeline_flow(file_infos: List[Dict[str, Any]]) -> List[str]:
        flow = []
        role_names = {i["role"] for i in file_infos}
        if "Application entry point" in role_names:
            flow.append("Application entry point")
        if "Configuration" in role_names:
            flow.append("Configuration")
        kinds = [AnalyzerService._score_role_kind(i["path"], i["role"]) for i in file_infos]
        for stage in ["detect", "track", "analytics", "api", "service", "database", "ui"]:
            if stage in kinds:
                flow.append(stage.title())
        return list(dict.fromkeys(flow))

    @staticmethod
    def _overview(repo_name: str, stack: List[str], file_infos: List[Dict[str, Any]], entry_points: List[str], role_counts: List[Dict[str, Any]], nested_archives: List[str]) -> str:
        stack_text = ", ".join(stack[:4]) if stack else "mixed technologies"
        role_text = ", ".join([f"{r['label']} ({r['value']})" for r in role_counts[:3]]) or "General module"
        entry_text = ", ".join(entry_points[:3]) if entry_points else "No obvious entry point detected."
        nested_text = f" The analyzer also expanded {len(nested_archives)} nested archive(s)." if nested_archives else ""
        return f"{repo_name} looks like a {stack_text} project with {len(file_infos)} supported source files. The strongest structural signals suggest modules around {role_text}. Likely entry points include: {entry_text}.{nested_text}"

    @staticmethod
    def _architecture_notes(file_infos: List[Dict[str, Any]], stack: List[str], entry_points: List[str], nested_archives: List[str]) -> List[str]:
        roles = sorted(list(dict.fromkeys(i["role"] for i in file_infos if i["role"] != "Documentation")))
        notes = []
        if roles:
            notes.append(f"The repository separates concerns across roles such as: {', '.join(roles)}.")
        if entry_points:
            notes.append(f"Detected startup or execution-oriented files: {', '.join(entry_points)}.")
        if nested_archives:
            notes.append(f"The analyzer expanded {len(nested_archives)} nested archive(s), so code stored inside inner zip files was included in this analysis.")
        if stack:
            notes.append(f"The dominant implementation stack appears to be: {', '.join(stack[:4])}.")
        return notes

    @staticmethod
    def _build_readme_draft(repo_name: str, overview: str, stack: List[str], key_modules: List[Dict[str, Any]], entry_points: List[str], architecture_notes: List[str], nested_archives: List[str]) -> str:
        lines = [f"# {repo_name}", "", "## Overview", overview, "", "## Detected Stack"]
        for item in stack:
            lines.append(f"- {item}")
        lines.extend(["", "## Key Modules"])
        for km in key_modules:
            lines.append(f"- `{km['path']}`: {km['role']} ({km['language']})")
        lines.extend(["", "## Entry Points"])
        if entry_points:
            for ep in entry_points:
                lines.append(f"- `{ep}`")
        else:
            lines.append("- No obvious entry point detected")
        lines.extend(["", "## Architecture Notes"])
        for note in architecture_notes:
            lines.append(f"- {note}")
        if nested_archives:
            lines.extend(["", "## Nested Archives Included"])
            for arc in nested_archives:
                lines.append(f"- `{arc}`")
        lines.extend(["", "## Suggested Next Step", "Validate the detected entry points, then add a hand-written architecture diagram and a short data-flow section to confirm the real execution path."])
        return "\n".join(lines)

    @staticmethod
    def _build_onboarding(file_infos: List[Dict[str, Any]], entry_points: List[str]) -> List[str]:
        guide = []
        if entry_points:
            guide.append(f"Start with {entry_points[0]} to understand how the project boots.")
        config_files = [i for i in file_infos if i["role"] == "Configuration"]
        if config_files:
            guide.append(f"Review {config_files[0]['path']} for runtime options and configuration defaults.")
        dep_files = [i for i in file_infos if i["role"] == "Dependency manifest"]
        if dep_files:
            guide.append(f"Check {dep_files[0]['path']} to understand external dependencies.")
        docs = [i for i in file_infos if i["role"] == "Documentation"]
        if docs:
            guide.append(f"Use {docs[0]['path']} to confirm the intended workflow and usage notes.")
        return guide[:5]

    @staticmethod
    def _mermaid(flow: List[str], entry_points: List[str]) -> str:
        lines = ["flowchart LR"]
        entry_label = entry_points[0] if entry_points else "No obvious entry point"
        lines.append(f'    Entry["{entry_label}"]')
        prev = "Entry"
        if not flow:
            lines.append('    Entry --> Unknown["Unknown flow"]')
            return "\n".join(lines)
        for idx, step in enumerate(flow, start=1):
            node_id = f"N{idx}"
            lines.append(f'    {node_id}["{step}"]')
            lines.append(f"    {prev} --> {node_id}")
            prev = node_id
        return "\n".join(lines)

    @staticmethod
    def _plantuml(flow: List[str], entry_points: List[str]) -> str:
        lines = ["@startuml", f":{entry_points[0] if entry_points else 'No obvious entry point'};"]
        for step in flow:
            lines.append(f":{step};")
        lines.append("@enduml")
        return "\n".join(lines)

    @staticmethod
    def _similar_repositories(current: Dict[str, Any]) -> List[Dict[str, Any]]:
        current_stack = set(current.get("detected_stack", []))
        results = []
        for item in AnalyzerService.ANALYSIS_HISTORY[-20:]:
            if item["analysis_id"] == current["analysis_id"]:
                continue
            other_stack = set(item.get("detected_stack", []))
            overlap = len(current_stack.intersection(other_stack))
            if overlap > 0:
                results.append({
                    "repo_name": item["repo_name"],
                    "similarity_score": min(100, overlap * 20),
                    "reason": f"Shares {overlap} major stack or architecture signals.",
                    "analysis_id": item["analysis_id"],
                })
        results.sort(key=lambda x: -x["similarity_score"])
        return results[:5]

    @staticmethod
    def _build_file_infos(files: List[Path], root: Path) -> List[Dict[str, Any]]:
        infos = []
        for f in files:
            rel_path = AnalyzerService._normalize_nested_display(AnalyzerService._rel(f, root))
            text = AnalyzerService._safe_read_text(f) if AnalyzerService._is_text_like(f) else ""
            infos.append({
                "path": rel_path,
                "absolute_path": str(f),
                "language": AnalyzerService._language_for_path(f),
                "role": AnalyzerService._detect_role(f, text),
                "line_count": AnalyzerService._line_count(f),
                "preview": text[:4000],
            })
        return infos

    @staticmethod
    def _analyze_root(root: Path, repository_name: str, source: str) -> Dict[str, Any]:
        nested_archives = AnalyzerService._expand_nested_archives(root)
        all_supported_files = [p for p in root.rglob("*") if p.is_file() and AnalyzerService._is_supported_source(p)]
        file_infos = AnalyzerService._build_file_infos(all_supported_files, root)
        dependency_edges = AnalyzerService._build_dependency_edges(all_supported_files, root)
        entry_points = AnalyzerService._find_entry_points(all_supported_files, root)
        stack = AnalyzerService._detect_stack(all_supported_files, root)
        language_breakdown = AnalyzerService._language_breakdown(all_supported_files)
        role_breakdown = AnalyzerService._role_breakdown(file_infos)
        overview = AnalyzerService._overview(repository_name, stack, file_infos, entry_points, role_breakdown, nested_archives)
        architecture_notes = AnalyzerService._architecture_notes(file_infos, stack, entry_points, nested_archives)
        graph_nodes = AnalyzerService._graph_nodes(file_infos)
        graph_edges = AnalyzerService._graph_edges(dependency_edges, file_infos)
        health = AnalyzerService._health_score(file_infos, entry_points, dependency_edges)
        anti_patterns = AnalyzerService._anti_patterns(file_infos, nested_archives, dependency_edges)
        refactor_suggestions = AnalyzerService._refactor_suggestions(file_infos, nested_archives)
        dependency_risks = AnalyzerService._dependency_risks(all_supported_files)
        pipeline_flow = AnalyzerService._pipeline_flow(file_infos)
        key_modules = sorted(file_infos, key=lambda x: (0 if x["role"] == "Application entry point" else 1 if x["role"] == "Configuration" else 2 if x["role"] == "Dependency manifest" else 3, x["path"]))[:12]
        readme_draft = AnalyzerService._build_readme_draft(repository_name, overview, stack, key_modules, entry_points, architecture_notes, nested_archives)
        onboarding = AnalyzerService._build_onboarding(file_infos, entry_points)
        analysis_id = str(uuid.uuid4())
        result = {
            "analysis_id": analysis_id,
            "repo_name": repository_name,
            "repo_source": source,
            "overview": overview,
            "project_summary": f"{repository_name} is built mainly with {', '.join(stack[:3]) if stack else 'mixed technologies'}.",
            "detected_stack": stack,
            "key_modules": [{"path": i["path"], "language": i["language"], "role": i["role"], "lines": i["line_count"]} for i in key_modules],
            "entry_points": entry_points,
            "architecture_notes": architecture_notes,
            "onboarding_guide": onboarding,
            "pipeline_flow": pipeline_flow,
            "file_tree": [i["path"] for i in sorted(file_infos, key=lambda x: x["path"])],
            "dependency_edges": [{"source": e["from"], "target": e["to"]} for e in dependency_edges],
            "architecture_mermaid": AnalyzerService._mermaid(pipeline_flow, entry_points),
            "architecture_svg_nodes": graph_nodes,
            "architecture_svg_edges": graph_edges,
            "generated_readme": readme_draft,
            "total_supported_files": len(file_infos),
            "total_scanned_files": len([p for p in root.rglob('*') if p.is_file()]),
            "nested_archives_processed": len(nested_archives),
            "discovered_archives": nested_archives,
            "language_breakdown": language_breakdown,
            "role_breakdown": role_breakdown,
            "health_score": health["score"],
            "health_breakdown": health["parts"],
            "anti_patterns": anti_patterns,
            "refactor_suggestions": refactor_suggestions,
            "security_findings": dependency_risks,
            "similar_repositories": [],
            "repo_signals": [
                {"label": "Entry points", "value": len(entry_points)},
                {"label": "Dependency edges", "value": len(dependency_edges)},
                {"label": "Nested archives", "value": len(nested_archives)},
                {"label": "Key modules", "value": len(key_modules)},
            ],
            "mermaid": AnalyzerService._mermaid(pipeline_flow, entry_points),
            "plantuml": AnalyzerService._plantuml(pipeline_flow, entry_points),
            "root_path": str(root),
            "files_index": file_infos,
        }
        result["similar_repositories"] = AnalyzerService._similar_repositories(result)
        AnalyzerService.ANALYSIS_STORE[analysis_id] = result
        AnalyzerService.ANALYSIS_HISTORY.append({
            "analysis_id": analysis_id,
            "repo_name": repository_name,
            "detected_stack": stack,
        })
        return result

    @staticmethod
    def search_existing_analysis(result_file: Path, query: str) -> Dict[str, Any]:
        data = json.loads(result_file.read_text(encoding="utf-8"))
        query_l = (query or "").strip().lower()
        if not query_l:
            return {"analysis_id": data["analysis_id"], "query": query, "explanation": "Enter a search query.", "results": []}
        hits = []
        for file_info in data.get("files_index", []):
            path = file_info["path"]
            preview = file_info.get("preview", "")
            score = 0
            if query_l in path.lower():
                score += 5
            if query_l in preview.lower():
                score += 3
            if score == 0:
                continue
            matched_line = None
            snippet = ""
            for idx, line in enumerate(preview.splitlines(), start=1):
                if query_l in line.lower():
                    matched_line = idx
                    snippet = line.strip()
                    break
            hits.append({"path": path, "matched_line": matched_line, "snippet": snippet or path, "reason": f"Matched in {file_info['role']} ({file_info['language']})", "score": score})
        hits.sort(key=lambda x: (-x["score"], x["path"]))
        slim = [{k: v for k, v in item.items() if k != "score"} for item in hits[:AnalyzerService.MAX_SEARCH_RESULTS]]
        return {"analysis_id": data["analysis_id"], "query": query, "explanation": f"Found {len(slim)} matching result(s).", "results": slim}

    @staticmethod
    def ask_existing_analysis(result_file: Path, question: str) -> Dict[str, Any]:
        data = json.loads(result_file.read_text(encoding="utf-8"))
        q = (question or "").strip().lower()
        answer = "Ask a question such as 'How does this codebase start running?' or 'What should I refactor first?'"
        source_results = []
        if any(word in q for word in ["start", "run", "entry", "boot"]):
            eps = data.get("entry_points", [])
            if eps:
                answer = f"Start with {eps[0]} to understand how the application boots or runs."
                source_results = [{"path": eps[0], "matched_line": None, "snippet": "Likely application entry point", "reason": "Entry point signal"}]
        elif any(word in q for word in ["config", "setting", "environment"]):
            for module in data.get("key_modules", []):
                if module.get("role") == "Configuration":
                    answer = f"The main configuration signal appears to be {module['path']}."
                    source_results = [{"path": module["path"], "matched_line": None, "snippet": "Configuration file", "reason": "Configuration signal"}]
                    break
        elif any(word in q for word in ["refactor", "improve"]):
            suggestions = data.get("refactor_suggestions", [])
            if suggestions:
                answer = f"Top refactor suggestion: {suggestions[0]['title']}. {suggestions[0]['detail']}"
        elif any(word in q for word in ["problem", "anti", "risk"]):
            anti = data.get("anti_patterns", [])
            if anti:
                answer = f"Main anti-pattern detected: {anti[0]['title']}. {anti[0]['detail']}"
        return {"question": question, "answer": answer, "sources": source_results, "mode": "heuristic AI assistant"}

    @staticmethod
    def export_existing_analysis(result_file: Path) -> Dict[str, Any]:
        data = json.loads(result_file.read_text(encoding="utf-8"))
        return {"analysis_id": data["analysis_id"], "mermaid": data["mermaid"], "plantuml": data["plantuml"]}


class CodebaseAnalyzer:
    def __init__(self, zip_path: Path, extract_path: Path, repo_source: str = "Uploaded zip"):
        self.zip_path = Path(zip_path)
        self.extract_path = Path(extract_path)
        self.repo_source = repo_source

    @staticmethod
    def fetch_github_repo(github_url: str, dest_zip_path: Path) -> str:
        return AnalyzerService.fetch_github_repo(github_url, dest_zip_path)

    def run(self) -> Dict[str, Any]:
        if self.extract_path.exists():
            shutil.rmtree(self.extract_path, ignore_errors=True)
        self.extract_path.mkdir(parents=True, exist_ok=True)
        root = AnalyzerService._extract_zip(self.zip_path, self.extract_path)
        repo_name = root.name if root.name else self.zip_path.stem
        result = AnalyzerService._analyze_root(root=root, repository_name=repo_name, source=self.repo_source)
        stable_id = self.extract_path.name
        old_id = result.get("analysis_id")
        result["analysis_id"] = stable_id
        if old_id in AnalyzerService.ANALYSIS_STORE:
            AnalyzerService.ANALYSIS_STORE.pop(old_id, None)
        AnalyzerService.ANALYSIS_STORE[stable_id] = result
        for item in reversed(AnalyzerService.ANALYSIS_HISTORY):
            if item.get("analysis_id") == old_id:
                item["analysis_id"] = stable_id
                break
        result_file = self.extract_path / "analysis.json"
        result_file.write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")
        return result

    @staticmethod
    def search_existing_analysis(result_file: Path, query: str) -> Dict[str, Any]:
        return AnalyzerService.search_existing_analysis(result_file, query)

    @staticmethod
    def ask_existing_analysis(result_file: Path, question: str) -> Dict[str, Any]:
        return AnalyzerService.ask_existing_analysis(result_file, question)

    @staticmethod
    def export_existing_analysis(result_file: Path) -> Dict[str, Any]:
        return AnalyzerService.export_existing_analysis(result_file)
