from pathlib import Path
import shutil
import uuid

from fastapi import APIRouter, File, Form, HTTPException, Request, UploadFile

from app.services.analyzer import CodebaseAnalyzer
from app.utils.schemas import AnalysisResponse, AskAnswer, AskRequest, ExportResponse, SearchRequest, SearchResponse

router = APIRouter(tags=["analysis"])
UPLOAD_DIR = Path("uploads")
UPLOAD_DIR.mkdir(exist_ok=True)


@router.get("/health")
async def health():
    return {"status": "ok"}


@router.api_route("/analyze", methods=["POST", "GET"], response_model=AnalysisResponse)
async def analyze_codebase(
    request: Request,
    file: UploadFile | None = File(default=None),
    github_url: str | None = Form(default=None),
):
    if request.method == "GET":
        github_url = request.query_params.get("github_url") or request.query_params.get("url")
    else:
        content_type = request.headers.get("content-type", "")
        if "application/json" in content_type:
            payload = await request.json()
            github_url = (payload or {}).get("github_url") or (payload or {}).get("url")
        elif not github_url:
            form = await request.form()
            github_url = form.get("github_url") or form.get("url")
            maybe_file = form.get("file")
            if isinstance(maybe_file, UploadFile):
                file = maybe_file

    github_url = github_url.strip() if isinstance(github_url, str) else github_url
    if not file and not github_url:
        raise HTTPException(status_code=400, detail="Upload a .zip file or provide a public GitHub repository URL.")

    analysis_id = str(uuid.uuid4())
    zip_path = UPLOAD_DIR / f"{analysis_id}.zip"
    extract_path = UPLOAD_DIR / analysis_id

    repo_source = "Uploaded zip"
    try:
        if github_url:
            repo_source = CodebaseAnalyzer.fetch_github_repo(github_url, zip_path)
        else:
            filename = file.filename or "repo.zip"
            if not filename.lower().endswith(".zip"):
                raise HTTPException(status_code=400, detail="Please upload a .zip file.")
            with zip_path.open("wb") as buffer:
                shutil.copyfileobj(file.file, buffer)
        analyzer = CodebaseAnalyzer(zip_path=zip_path, extract_path=extract_path, repo_source=repo_source)
        return analyzer.run()
    except HTTPException:
        raise
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail=f"Analysis failed: {exc}") from exc


@router.post("/search", response_model=SearchResponse)
async def search_codebase(payload: SearchRequest):
    result_file = UPLOAD_DIR / payload.analysis_id / "analysis.json"
    if not result_file.exists():
        raise HTTPException(status_code=404, detail="Analysis ID not found.")
    return CodebaseAnalyzer.search_existing_analysis(result_file, payload.query)


@router.post("/ask", response_model=AskAnswer)
async def ask_codebase(payload: AskRequest):
    result_file = UPLOAD_DIR / payload.analysis_id / "analysis.json"
    if not result_file.exists():
        raise HTTPException(status_code=404, detail="Analysis ID not found.")
    return CodebaseAnalyzer.ask_existing_analysis(result_file, payload.question)


@router.get("/export/{analysis_id}", response_model=ExportResponse)
async def export_architecture(analysis_id: str):
    result_file = UPLOAD_DIR / analysis_id / "analysis.json"
    if not result_file.exists():
        raise HTTPException(status_code=404, detail="Analysis ID not found.")
    return CodebaseAnalyzer.export_existing_analysis(result_file)
