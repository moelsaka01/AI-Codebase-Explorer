from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles

from app.core import BASE_DIR
from app.routes.web import router as web_router
from app.routes.api import router as api_router

app = FastAPI(title="AI Codebase Explorer", version="3.4.0")
app.mount("/static", StaticFiles(directory=str(BASE_DIR / "static")), name="static")

app.include_router(web_router)
app.include_router(api_router, prefix="/api")
